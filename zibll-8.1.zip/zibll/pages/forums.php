<?php

/**
 * Template name: Zibll-论坛首页
 * Description:   社区论坛首页
 */



require get_theme_file_path('inc/functions/bbs/page/home.php');
